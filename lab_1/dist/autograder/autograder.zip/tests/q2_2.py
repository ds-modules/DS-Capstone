test = {   'name': 'q2_2',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> \n>>> assert num_columns == 16\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
