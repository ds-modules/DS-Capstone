test = {   'name': 'q1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> assert len(cereal.columns) == 16\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert type(cereal) == type(pd.DataFrame())\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
