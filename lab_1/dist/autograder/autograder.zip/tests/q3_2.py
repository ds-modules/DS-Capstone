test = {   'name': 'q3_2',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert (most_protein == 'Cheerios' or most_protein == 'Special K')\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
