test = {   'name': 'q0_2',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> assert "education" not in defaults.columns\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert "marital_status" not in defaults.columns\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert "sex_male" in defaults.columns\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
