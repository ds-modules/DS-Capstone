test = {   'name': 'q2_1',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> q2_1 in ["a", "b", "c", "d", "e"]\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> q2_1 == "b"\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
