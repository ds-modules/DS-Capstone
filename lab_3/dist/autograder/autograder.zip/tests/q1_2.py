test = {   'name': 'q1_2',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> np.random.seed(1234);\n'
                                               '>>> x2 = np.random.uniform(0, 10, 5);\n'
                                               '>>> y2 = np.random.uniform(0, 10, 5);\n'
                                               '>>> np.isclose(slope(x2, y2), 0.853965497371089)\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.random.seed(1234);\n'
                                               '>>> x2 = np.random.uniform(0, 10, 5);\n'
                                               '>>> y2 = np.random.uniform(0, 10, 5);\n'
                                               '>>> np.isclose(intercept(x2, y2), 1.5592892975597108)\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.random.seed(2345);\n'
                                               '>>> x2 = np.random.uniform(0, 10, 5);\n'
                                               '>>> y2 = np.random.uniform(0, 10, 5);\n'
                                               '>>> np.isclose(slope(x2, y2), -0.5183482739336265)\n'
                                               'True',
                                       'hidden': True,
                                       'locked': False},
                                   {   'code': '>>> np.random.seed(2345);\n'
                                               '>>> x2 = np.random.uniform(0, 10, 5);\n'
                                               '>>> y2 = np.random.uniform(0, 10, 5);\n'
                                               '>>> np.isclose(intercept(x2, y2), 7.777051922080558)\n'
                                               'True',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
