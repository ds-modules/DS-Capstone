test = {   'name': 'q2_6',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> 22000 <= new_rmse <= 23000\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(new_rmse, 22520.134070208653)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
