test = {   'name': 'q1_1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> np.random.seed(1234);\n'
                                               '>>> x2 = np.random.uniform(0, 10, 5);\n'
                                               '>>> y2 = np.random.uniform(0, 10, 5);\n'
                                               '>>> np.isclose(corr(x2, y2), 0.6410799722591175)\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.random.seed(2345);\n'
                                               '>>> x2 = np.random.uniform(0, 10, 5);\n'
                                               '>>> y2 = np.random.uniform(0, 10, 5);\n'
                                               '>>> np.isclose(corr(x2, y2), -0.4008555019904271)\n'
                                               'True',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
