test = {   'name': 'q2_5',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> len(new_features) == 6\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> new_X.shape[1] == 6\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(new_Y_hat) == defaults.shape[0]\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
