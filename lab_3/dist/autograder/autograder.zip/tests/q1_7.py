test = {   'name': 'q1_7',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> np.random.seed(1234);\n'
                                               '>>> y2 = np.random.uniform(0, 10, 5);\n'
                                               '>>> y_hat2 = np.random.uniform(0, 10, 5);\n'
                                               '>>> np.isclose(rmse(y2, y_hat2), 2.440102731334708)\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.random.seed(2345);\n'
                                               '>>> y2 = np.random.uniform(0, 10, 5);\n'
                                               '>>> y_hat2 = np.random.uniform(0, 10, 5);\n'
                                               '>>> np.isclose(rmse(y2, y_hat2), 4.034226624125118)\n'
                                               'True',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
