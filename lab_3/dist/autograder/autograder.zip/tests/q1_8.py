test = {   'name': 'q1_8',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> 70000 <= single_var_error <= 80000\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(single_var_error, 70571.40305975602)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
