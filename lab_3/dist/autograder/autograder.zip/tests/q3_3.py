test = {   'name': 'q3_3',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> my_X = defaults[my_labels];\n'
                                               '>>> my_model = lm.LinearRegression().fit(my_X, Y);\n'
                                               '>>> my_Y_hat = my_model.predict(my_X);\n'
                                               '>>> rmse(Y, my_Y_hat) <= 25000;\n'
                                               '>>> \n'
                                               'True',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
