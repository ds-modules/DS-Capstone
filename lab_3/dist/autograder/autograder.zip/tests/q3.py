test = {   'name': 'q3',
    'points': 3,
    'suites': [   {   'cases': [{'code': '>>> len(my_labels) <= 10\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> "bill_sep05" not in my_labels\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
