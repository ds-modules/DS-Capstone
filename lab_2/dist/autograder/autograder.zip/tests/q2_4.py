test = {   'name': 'q2_4',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> assert viral_times[0] == '22'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert viral_times[4] == '15'\n", 'hidden': False, 'locked': False},
                                   {'code': '>>> assert viral_times.shape[0] == 936\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
