test = {   'name': 'q1_4',
    'points': 1,
    'suites': [{'cases': [{'code': ">>> assert 'thumbnail_link' not in trending_vids.columns\n", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
