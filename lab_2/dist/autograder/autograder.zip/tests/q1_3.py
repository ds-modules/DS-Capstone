test = {   'name': 'q1_3',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> assert type(trending_vids.dtypes.loc['trending_date'] == 'datetime64[ns]')\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert type(trending_vids.dtypes.loc['publish_time'] == 'datetime64[ns]')\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
