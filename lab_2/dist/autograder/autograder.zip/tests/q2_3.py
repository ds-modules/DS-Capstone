test = {   'name': 'q2_3',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> assert viral_channels[0] == 'The King of Random';\n>>> \n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert viral_channels[1] == 'NBA'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert viral_channels[2] == 'The Tonight Show Starring Jimmy Fallon'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
