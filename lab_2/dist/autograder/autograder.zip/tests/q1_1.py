test = {   'name': 'q1_1',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> assert missing.iloc[0] == 19\n', 'hidden': False, 'locked': False}, {'code': '>>> assert sum(missing) == 109\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
